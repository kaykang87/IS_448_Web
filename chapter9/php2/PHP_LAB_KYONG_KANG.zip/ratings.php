<html>
    <head>
        <title>Movie Rating Response</title>
        <link rel="stylesheet" type="text/css" href="form_proc.css"/>
    </head>
    <body>
        <p>
        <?php

        $movieName = $_POST["movie_name"];
        $movieRating = $_POST["rating"];

        if ((isset($movieName) && (!empty($movieName))))

        {
        ?>

        Thank you for the rating for the movie
        <strong><?php echo $movieName ?></strong> of 
        <strong> "<?php echo $movieRating ?>" </strong>
        </p>
        <?php
        }
        else {
            echo "You haven't entered the required informations";
        }
        ?>
    </body>
</html>